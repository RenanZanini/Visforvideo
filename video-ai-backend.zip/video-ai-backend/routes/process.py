from fastapi import APIRouter, Request
from services import gemini, openai_gen, dalle_gen, tts, montage, drive_upload, notion_export

router = APIRouter()

@router.post("/process")
async def process_video(request: Request):
    data = await request.json()
    video_url = data.get("video_url")

    analysis = gemini.analyze_video(video_url)
    script = openai_gen.generate_script(analysis)
    images = dalle_gen.generate_images(script)
    audio = tts.generate_audio(script)
    video_path = montage.create_video(images, audio)
    upload_link = drive_upload.upload_video(video_path)
    notion_export.send_summary(script, upload_link)

    return {"status": "completed", "video_link": upload_link}
