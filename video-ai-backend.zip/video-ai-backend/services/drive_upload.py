def upload_video(video_path):
    return f"https://drive.google.com/fake_link/{video_path}"
