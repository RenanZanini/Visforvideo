def generate_script(analysis_text):
    return f"Script gerado com base na análise: {analysis_text}"
