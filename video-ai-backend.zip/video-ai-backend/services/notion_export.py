def send_summary(script_text, link):
    print("Enviado ao Notion:", script_text, link)
