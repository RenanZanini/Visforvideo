def generate_images(script_text):
    return ["imagem1.png", "imagem2.png"]
