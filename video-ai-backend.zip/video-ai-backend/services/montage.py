def create_video(images, audio):
    return "video_final.mp4"
