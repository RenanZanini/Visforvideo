def generate_audio(script_text):
    return "audio.mp3"
