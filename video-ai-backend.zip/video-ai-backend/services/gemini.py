def analyze_video(video_url):
    return f"Análise simulada do vídeo: {video_url}"
